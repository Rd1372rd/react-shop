import React from "react";
import ReactDOM from "react-dom";
import "./Subtotal.css";
import CurrencyFormat from "./CurrencyFormat";
import { useState, useStateValue } from "./StateProvider";
import { getBasketTotal } from "./reducer";

const Subtotal = () => {
  const [{ basket }, dispatch] = useStateValue();
  return (
    <div className="Subtotal">
      <CurrencyFormat value={getBasketTotal(basket)} prefix="$" separator="," />
      <p>Subtotal ({basket.length} items):</p>
      <button>Proceed to Checkout</button>
    </div>
  );
};

export default Subtotal;
