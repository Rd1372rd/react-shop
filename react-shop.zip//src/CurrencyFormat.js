import React from "react";

function CurrencyFormat({ value, prefix = "$", separator = "," }) {
  const formattedValue = value
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, separator);

  return (
    <span>
      {prefix}
      {formattedValue}
    </span>
  );
}

export default CurrencyFormat;
