import React from "react";
import ReactDOM from "react-dom";
import { Link } from "react-router-dom";
import { useContext } from "react/cjs/react.production.min";
import { useStateValue } from "./StateProvider";
import "./Header.css";

const Header = () => {
  const [{ basket }] = useStateValue();
  return (
    <div className="header">
      <Link to="/home" style={{ textDecoration: "none" }}>
        <div className="header-logo">
          <i class="material-icons custom-icon">local_mall</i>
          <h2 className="header_logoTitle">eShop</h2>
        </div>
      </Link>

      <div className="header-search">
        <input type="text" className="header_searchInput" />
        <i class="material-icons custom-icon">search</i>
      </div>

      <div className="header-nav">
        <div className="nav-item">
          <span className="nav-itemLineOne">Hello Guest</span>
          <span className="nav-itemLineTwo">Sign In</span>
        </div>

        <div className="nav-item">
          <span className="nav-itemLineOne">Your</span>
          <span className="nav-itemLineTwo">Shop</span>
        </div>

        <Link to="/checkout" style={{ TextDecoration: "none" }}>
          <div className="nav-item">
            <span className="nav-itemLineOne">
              <i class="material-icons custom-icon">&#xe547;</i>
            </span>
            <span className="nav-itemLineTwo">({basket?.length || 0})</span>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Header;
