import "./Home.css";
import React from "react";
import ReactDOM from "react-dom";
import Product from "./Product";
import Header from "./Header";

const Home = () => {
  return (
    <div>
      <Header />
      <div className="home">
        <div className="home_container">
          <img src="/1.jpg" alt="HomeImage" className="home_image" />

          <div className="home_row">
            <Product
              id="123456"
              title="پایه لامپ اس ام دی 12 وات سایروکس بسته دو عددی"
              price={125000}
              rating={5}
              image="/lamp.jpg"
            />
            <Product
              id="753311"
              title="اسپاگتی قطر 1.2 زر ماکارون مقدار 700 گرم"
              price={25000}
              rating={3}
              image="/spageti.jpg"
            />
          </div>

          <div className="home_row">
            <Product
              id="56776798"
              title="رب گوجه فرنگی چین چین 800 گرم"
              price={35000}
              rating={1}
              image="/Robe.jpg"
            />
            <Product
              id="32867856"
              title="گوشی موبایل جی پلاس مدل دوسیم X10 Plus کارت ظرفیت 128 گیگابایت و رم 4 گیگابایت"
              price={5567000}
              rating={4}
              image="/mobile.jpg"
            />
            <Product
              id="123433467"
              title="ساعت هوشمند مدل 170 Radiant"
              price={3254000}
              rating={5}
              image="/watch.jpg"
            />
          </div>

          <div className="home_row">
            <Product
              id="634568232"
              title="ساعت هوشمند مدل ULTRA MAX"
              price={1870000}
              rating={3}
              image="/watch2.jpg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
