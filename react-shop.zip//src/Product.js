import React from "react";
import { useStateValue } from "./StateProvider"; // فرض می‌کنیم اینجا StateProvider را وارد کرده‌اید
import "./Product.css";

const Product = ({ id, title, image, price, rating }) => {
  const [{ basket }, dispatch] = useStateValue(); // استفاده صحیح از useStateValue

  const addToBasket = () => {
    // استفاده از dispatch به عنوان تابع
    dispatch({
      type: "ADD_TO_BASKET",
      item: {
        id: id,
        image: image,
        price: price,
        rating: rating,
      },
    });
  };

  return (
    <div className="product">
      <div className="product_container">
        <div className="product_info">
          <p>{title}</p>
          <p className="product_price">
            <small>$</small>
            <strong>{price}</strong>
          </p>
          <div className="product_rating">
            {Array(rating)
              .fill()
              .map((_, i) => (
                <p key={i}>
                  <i className="material-icons">&#xe838;</i>
                </p>
              ))}
          </div>
          <img src={image} alt={id} className="product_image" />
          <button onClick={addToBasket}>Add to Basket</button>{" "}
          {/* اتصال addToBasket به دکمه */}
        </div>
      </div>
    </div>
  );
};

export default Product;
